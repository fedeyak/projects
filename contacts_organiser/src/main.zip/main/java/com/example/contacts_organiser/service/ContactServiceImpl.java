//package com.example.contacts_organiser.service;
//
//import com.example.contacts_organiser.model.Contact;
//
//import java.util.List;
//
//public class ContactServiceImpl implements ContactService{
//    @Override
//    public void addContactLoader(ClassLoader classLoader) {
//
//    }
//
//    @Override
//    public void addContact(Contact contact) {
//
//    }
//
//    @Override
//    public void deleteContact(String email) {
//
//    }
//
//    @Override
//    public void saveContacts(List<Contact> contacts) {
//
//    }
//
//    @Override
//    public List<Contact> retrieveContacts() {
//        return List.of();
//    }
//}
