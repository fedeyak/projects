package com.example.contacts_organiser.service;

import com.example.contacts_organiser.repository.ContactRepository;
import org.springframework.stereotype.Service;

@Service
public class ContactService_apprentice {

    private final ContactRepository repository;

    public ContactService_apprentice() {
        repository = new ContactRepository();
    }

    public void showContacts() {
        System.out.println("Showing contacts");
        repository.showContacts();
    }

    public void addContact(String rawContact) {
        System.out.println("Adding contacts");
        repository.addContact(rawContact);
    }

    public void deleteContacts(String email) {
        System.out.println("Deleting contacts");
        repository.deleteContacts(email);
    }

    public void saveContacts() {
        System.out.println("Saving contacts");
        repository.saveContacts();
    }

    public void loadContacts() {
        System.out.println("Loading contacts");
        repository.loadContacts();
    }

}
