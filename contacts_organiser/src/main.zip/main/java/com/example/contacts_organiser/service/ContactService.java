//package com.example.contacts_organiser.service;
//
//import com.example.contacts_organiser.model.Contact;
//
//import java.util.List;
//
//public interface ContactService {
//
//    void addContactLoader(ClassLoader classLoader);
//    void addContact(Contact contact);
//    void deleteContact(String email);
//    void saveContacts(List<Contact> contacts);
//    List<Contact> retrieveContacts();
//}
