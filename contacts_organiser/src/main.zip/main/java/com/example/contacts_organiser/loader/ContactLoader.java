package com.example.contacts_organiser.loader;

public class ContactLoader {
}
